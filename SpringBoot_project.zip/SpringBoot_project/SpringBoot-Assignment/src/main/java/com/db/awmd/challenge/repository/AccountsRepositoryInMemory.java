package com.db.awmd.challenge.repository;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.Transaction;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {

  private final Map<String, Account> accounts = new ConcurrentHashMap<>();
  private final Map<String, Transaction> transactions = new ConcurrentHashMap<>();

  @Override
  public void createAccount(Account account) throws DuplicateAccountIdException {
    Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
    if (previousAccount != null) {
      throw new DuplicateAccountIdException(
        "Account id " + account.getAccountId() + " already exists!");
    }
  }

  @Override
  public Account getAccount(String accountId) {
    return accounts.get(accountId);
  }
  
  @Override
  public void updateAccount(String accountIdTo,BigDecimal amountToTransfer) {
     
	 Account currentAccount=getAccount(accountIdTo);
	 BigDecimal currentBalance=currentAccount.getBalance();
	 currentAccount.setBalance(currentBalance.add(amountToTransfer));
  }

  @Override
  public void clearAccounts() {
    accounts.clear();
  }

@Override
public String addTransactionDetails(Transaction transaction) {
	// TODO Auto-generated method stub
	Transaction newTransaction=transactions.put(transaction.getAccountIdTo(), transaction);
	if(newTransaction!=null)
	{
		if(accounts!=null)
		{
			updateAccount(transaction.getAccountIdTo(),transaction.getAmountToTransfer());
		}
	}
	return "Amount "+transaction.getAccountIdTo()+ "transfered from"+transaction.getAccountIdFrom()+ "to"+transaction.getAccountIdTo();
}

}
