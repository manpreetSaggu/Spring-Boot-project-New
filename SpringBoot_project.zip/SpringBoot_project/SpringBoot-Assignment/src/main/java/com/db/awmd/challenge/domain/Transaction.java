package com.db.awmd.challenge.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Data
public class Transaction {

	 @NotNull
	  @NotEmpty
	  private final String accountIdTo;
	 
	 @NotNull
	  @NotEmpty
	  private final String accountIdFrom;

	  @NotNull
	  @Min(value = 0, message = "Amount to be transferred.")
	  private BigDecimal amountToTransfer;
	  
	  public Transaction(String accountIdTo,String accountIdFrom) {
		  this.accountIdTo = accountIdTo;
		  this.accountIdFrom = accountIdFrom;
		  this.amountToTransfer = BigDecimal.ZERO;
	  }

	  @JsonCreator
	  public Transaction(@JsonProperty("accountIdTo") String accountIdTo,
			  @JsonProperty("accountIdFrom") String accountIdFrom,
			  @JsonProperty("amountToTransfer") BigDecimal amountToTransfer) {
		  this.accountIdTo = accountIdTo;
		  this.accountIdFrom = accountIdFrom;
		  this.amountToTransfer = amountToTransfer;
	  }

	public BigDecimal getAmountToTransfer() {
		return amountToTransfer;
	}


	public String getAccountIdTo() {
		return accountIdTo;
	}

	public String getAccountIdFrom() {
		return accountIdFrom;
	}
	  
}
